package com.local.tokenizer.detokenizer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokenizerDetokenizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
