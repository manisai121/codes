package com.local.tokenizer.detokenizer.dto.request;

import lombok.Data;

@Data
public class Student {

    private Long studentId;
    private String studentName;
    private Long studentRollNo;

}
