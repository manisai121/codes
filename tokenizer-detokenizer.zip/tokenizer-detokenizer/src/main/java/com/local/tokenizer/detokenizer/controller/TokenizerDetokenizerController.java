package com.local.tokenizer.detokenizer.controller;

import com.local.tokenizer.detokenizer.dto.request.Student;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TokenizerDetokenizerController {

    @GetMapping("/hello")
    public ResponseEntity<String> hello(){
        return ResponseEntity.ok().body("Hello World!");
    }

    @PostMapping("/student")
    public ResponseEntity<Student> student(@RequestBody Student student){
        // Will perform tokenization or detokenization here
        student.setStudentName(student.getStudentName() + "Updated");
        return ResponseEntity.ok().body(student);
    }
}
