GET
- URI http://localhost:8080/hello

POST
- URI: http://localhost:8080/student
- Request:
  {
  "studentId": 1,
  "studentName": "G2",
  "studentRollNo": 1
  }
- Response
  {
  "studentId": 1,
  "studentName": "G2Updated",
  "studentRollNo": 1
  }
